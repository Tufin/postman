/**** This function hides lines which have methods that
 don't correspond to the method used for the request ****/
function hideMethod() {
    var row = $(".endpoint"),
        httpMethodRef,
        matchProperty,
        currentHttpMethodRef,
        httpMethodRefLength,
        tableBody;

    $(row).each(function(){

        // In each operation row find the method type(AKA GET, POST, DELETE, PUT)

        var operationName = $(this).find(".http_method a").text(),
            descriptionDiv = $(this).find(".description div");

        descriptionDiv.each(function(i){

            // Go through all containing divs of properties and find the
            // httpMethod span that holds the httpMethod key and value
            // if  key value equals operation's method type then so leave it be
            // otherwise hide it from view.

            httpMethodRef = $(descriptionDiv[i]).find(".propHttp");
            httpMethodRefLength = httpMethodRef.length;

            if(httpMethodRefLength > 0) {

                matchProperty = false;

                for(var j = 0; j < httpMethodRefLength; j++) {

                    if(operationName == httpMethodRef[j].innerHTML.toLowerCase()) {
                        matchProperty = true;
                    }

                    currentHttpMethodRef = httpMethodRef[j];
                }

                if(!matchProperty){
                    $(currentHttpMethodRef).closest("div").css("display", "none");
                }

            }
        })
    });

    // Removes the column of 'Value-hidden' ('th' and 'td') from tables.
    tableBody = $(".operation-params");
    $(tableBody).find("td:nth-child(2)").remove();
    $("tr th:contains('Value-hidden')").each(function(){
        $(this).remove();
    });
}

/*** This function replace the parameters section at top ***/
function placeParameterSection() {
    var contentSection = $('.content'),
    contentSectionTitle = contentSection.find(".base-url");

    $(contentSection).each(function(i){
        var currentContentSectionTitle = contentSectionTitle[i],
            parameterSection = $('.sandbox')[i];
        $(currentContentSectionTitle).after(parameterSection);
    })
}

function markMandatoryParam() {
    var requiredParam = $(".code.required");
    requiredParam.prepend('<span class="mandatory-param">*</span>');
}


